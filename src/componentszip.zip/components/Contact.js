import React from 'react';
import "./Contact.css";
import { FaUser, FaEnvelope, FaPhone, FaPaperPlane } from 'react-icons/fa';

const Contact = () => {
    return (
        <section id="contact" className="contact">
            <h1 className="heading">Contact Us</h1>
            <h3 className="title">We are here to help you, anytime.</h3>
            <div className="row">
                <div className="images">
                    <img src="https://cdn-icons-png.flaticon.com/128/9374/9374883.png" alt="Contact" />
                </div>
                <div className="form-container">
                    <div className="input-group">
                        <FaUser className="icon" />
                        <input type="text" placeholder="Full Name" />
                    </div>
                    <div className="input-group">
                        <FaEnvelope className="icon" />
                        <input type="email" placeholder="Enter your email" />
                    </div>
                    <div className="input-group">
                        <FaPhone className="icon" />
                        <input type="number" placeholder="Phone" />
                    </div>
                    <div className="input-group">
                        <textarea cols="30" rows="10" placeholder="Your Message"></textarea>
                    </div>
                    <div className="input-group">
                        <input type="submit" value="Send" />
                        <FaPaperPlane className="send-icon" />
                    </div>
                </div>
            </div>
        </section>
    );
};

export default Contact;
